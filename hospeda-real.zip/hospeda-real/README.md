# hospeda-real

Plataforma funcional de hospedagem: qualquer pessoa pode subir um `.zip` com
um site estático ou uma API Node, e a plataforma extrai, instala as
dependências (se for API) e publica em uma URL própria — sem login.

## Como funciona

- **Site estático:** você sobe um zip com `index.html` na raiz. Fica
  disponível em `/site/<id>/`.
- **API Node:** você sobe um zip com um `index.js`, `server.js` ou `app.js`
  que escute em `process.env.PORT`. A plataforma roda `npm install` (se
  houver `package.json`) e sobe o processo. Fica disponível em `/api/<id>/`.
- O painel (`/`) lista os deploys, status, logs e permite excluir.

Dois zips de exemplo vêm junto pra você testar assim que subir:
`hospeda-real-exemplo-site.zip` (site estático) e
`hospeda-real-exemplo-api.zip` (API Node).

## Rodando localmente

```bash
npm install
npm start
```

Acesse `http://localhost:3000`.

## Subindo pro GitHub

```bash
cd hospeda-real
git init
git add .
git commit -m "primeiro commit: hospeda-real"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

## Deploy no Render

Esse projeto **precisa de disco persistente**, porque os arquivos enviados
(sites e código das APIs) ficam salvos em `data/`. Sem disco, tudo some a
cada reinício/redeploy. Disco persistente exige plano pago (Starter ou
superior) — o `render.yaml` já vem configurado assim.

**Com Blueprint:**
1. Suba o projeto pro GitHub.
2. No painel do Render: **New +** → **Blueprint** → selecione o repositório.
3. O Render lê o `render.yaml`, já cria o disco e o serviço. Clique em **Apply**.

**Manual (se preferir configurar você mesmo):**
1. **New +** → **Web Service** → conecte o repositório.
2. Build Command: `npm install` · Start Command: `npm start`.
3. Em **Disks**, adicione um disco (ex: 1GB) montado em
   `/opt/render/project/src/data`.

## ⚠️ Limitações importantes (leia antes de deixar público)

Esta é uma plataforma **funcional**, mas ainda é um MVP. Antes de expor pra
estranhos na internet, saiba:

1. **Isolamento fraco.** As APIs dos usuários rodam como processos Node
   normais no mesmo servidor — não em containers separados. Um código
   malicioso pode, em teoria, acessar arquivos de outros deploys ou consumir
   toda a memória/CPU do servidor. Para produção de verdade, o próximo passo
   é rodar cada API em um container isolado (Docker + limites de CPU/memória),
   não como processo direto.
2. **Sem autenticação.** Qualquer pessoa que acesse o site pode subir,
   listar e excluir deploys de qualquer um. Adicionar login é o primeiro
   passo antes de divulgar a plataforma.
3. **Sem limite de uso por pessoa.** Não há quota de quantos deploys ou
   quanto tráfego cada "usuário" pode gerar — hoje é livre.
4. **Uma única instância.** Se o serviço do Render reiniciar, todas as APIs
   em execução precisam subir de novo (o painel mostra "instalando" até
   ficarem online outra vez); os arquivos continuam salvos graças ao disco.
5. **Domínio único.** Os sites/APIs ficam em subpastas
   (`/site/<id>/`, `/api/<id>/`) da mesma URL do Render, não em subdomínios
   próprios (`meusite.hospeda.dev`). Subdomínios de verdade exigem DNS
   curinga (`*.hospeda.dev`) apontando pro Render e lógica extra de
   roteamento por host — dá pra evoluir para isso depois.

## Próximos passos sugeridos, em ordem de prioridade

1. Autenticação (login) e um deploy só poder ser gerenciado por quem o criou.
2. Isolar cada API em container (mais seguro, também mais trabalho).
3. Subdomínios reais via DNS curinga.
4. Limites de plano (quantos sites/APIs por conta, tráfego, etc).
