const form = document.getElementById("upload-form");
const feedback = document.getElementById("upload-feedback");
const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("file-input");
const dropzoneLabel = document.getElementById("dropzone-label");
const deploysList = document.getElementById("deploys-list");
const refreshBtn = document.getElementById("refresh-btn");

const logModal = document.getElementById("log-modal");
const logModalTitle = document.getElementById("log-modal-title");
const logModalBody = document.getElementById("log-modal-body");
document.getElementById("log-modal-close").addEventListener("click", () => logModal.classList.add("hidden"));

// ---------- Dropzone ----------
fileInput.addEventListener("change", () => {
  dropzoneLabel.textContent = fileInput.files[0] ? fileInput.files[0].name : "Arraste um .zip aqui ou clique para escolher";
});
["dragenter", "dragover"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.add("drag"); })
);
["dragleave", "drop"].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => { e.preventDefault(); dropzone.classList.remove("drag"); })
);
dropzone.addEventListener("drop", (e) => {
  if (e.dataTransfer.files[0]) {
    fileInput.files = e.dataTransfer.files;
    dropzoneLabel.textContent = e.dataTransfer.files[0].name;
  }
});

// ---------- Upload ----------
form.addEventListener("submit", async (e) => {
  e.preventDefault();
  feedback.textContent = "Enviando e fazendo deploy...";
  feedback.className = "feedback";

  const formData = new FormData(form);
  try {
    const res = await fetch("/api-painel/upload", { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) {
      feedback.textContent = data.erro || "Erro no upload.";
      feedback.className = "feedback erro";
      return;
    }
    feedback.textContent = `Deploy criado: ${data.url}`;
    form.reset();
    dropzoneLabel.textContent = "Arraste um .zip aqui ou clique para escolher";
    carregarDeploys();
  } catch (err) {
    feedback.textContent = "Falha ao enviar: " + err.message;
    feedback.className = "feedback erro";
  }
});

// ---------- Listagem ----------
async function carregarDeploys() {
  const res = await fetch("/api-painel/deploys");
  const deploys = await res.json();

  if (deploys.length === 0) {
    deploysList.innerHTML = '<p class="muted">Nenhum deploy ainda. Suba um .zip acima.</p>';
    return;
  }

  deploysList.innerHTML = deploys.map((d) => renderDeployCard(d)).join("");

  deploysList.querySelectorAll("[data-logs]").forEach((btn) => {
    btn.addEventListener("click", () => abrirLogs(btn.dataset.logs, btn.dataset.name));
  });
  deploysList.querySelectorAll("[data-delete]").forEach((btn) => {
    btn.addEventListener("click", () => excluirDeploy(btn.dataset.delete));
  });
}

function renderDeployCard(d) {
  const statusClass = "status-" + (d.status || "").replace(/\s.*/, "");
  const url = d.type === "static" ? `/site/${d.id}/` : `/api/${d.id}/`;
  const logsBtn = d.type === "api" ? `<button class="btn btn-outline btn-small" data-logs="${d.id}" data-name="${d.name}">Logs</button>` : "";
  return `
    <div class="deploy-card">
      <div class="deploy-info">
        <div class="deploy-name">${escapeHtml(d.name || d.id)} <span class="status-pill ${statusClass}">${d.status}</span></div>
        <div class="deploy-meta">${d.type === "static" ? "site estático" : "api node"} · <a href="${url}" target="_blank">${url}</a></div>
        ${d.error ? `<div class="deploy-meta" style="color:#F0685C">${escapeHtml(d.error)}</div>` : ""}
        ${d.warning ? `<div class="deploy-meta" style="color:#F2A93B">${escapeHtml(d.warning)}</div>` : ""}
      </div>
      <div class="deploy-actions">
        ${logsBtn}
        <button class="btn btn-outline btn-small" data-delete="${d.id}">Excluir</button>
      </div>
    </div>`;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function abrirLogs(id, name) {
  logModalTitle.textContent = `Logs — ${name || id}`;
  logModalBody.textContent = "Carregando...";
  logModal.classList.remove("hidden");
  const res = await fetch(`/api-painel/logs/${id}`);
  const data = await res.json();
  logModalBody.textContent = data.logs.length ? data.logs.join("\n") : "Sem logs ainda.";
}

async function excluirDeploy(id) {
  if (!confirm("Excluir esse deploy?")) return;
  await fetch(`/api-painel/deploys/${id}`, { method: "DELETE" });
  carregarDeploys();
}

refreshBtn.addEventListener("click", carregarDeploys);
carregarDeploys();
setInterval(carregarDeploys, 8000); // atualiza status (útil enquanto uma API está "instalando")
