const express = require("express");
const multer = require("multer");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const { nanoid } = require("nanoid");
const { createProxyMiddleware } = require("http-proxy-middleware");

const registry = require("./lib/registry");
const { extractZipSafe, flattenSingleRoot } = require("./lib/deploy");
const runner = require("./lib/runner");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, "data");

fs.mkdirSync(path.join(DATA_DIR, "sites"), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, "apis"), { recursive: true });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }, // 25MB
});

// ---------- Listar deploys ----------
app.get("/api-painel/deploys", (req, res) => {
  const db = registry.all();
  const list = Object.entries(db).map(([id, r]) => ({ id, ...r }));
  list.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  res.json(list);
});

app.get("/api-painel/logs/:id", (req, res) => {
  res.json({ logs: runner.getLogs(req.params.id) });
});

app.delete("/api-painel/deploys/:id", (req, res) => {
  const { id } = req.params;
  const record = registry.get(id);
  if (!record) return res.status(404).json({ erro: "Deploy não encontrado." });

  if (record.type === "api") {
    runner.stopApi(id);
    fs.rmSync(path.join(DATA_DIR, "apis", id), { recursive: true, force: true });
  } else {
    fs.rmSync(path.join(DATA_DIR, "sites", id), { recursive: true, force: true });
  }
  registry.remove(id);
  res.json({ ok: true });
});

// ---------- Upload / deploy ----------
app.post("/api-painel/upload", upload.single("arquivo"), async (req, res) => {
  const { tipo, nome } = req.body;
  if (!req.file) return res.status(400).json({ erro: "Envie um arquivo .zip." });
  if (!["static", "api"].includes(tipo)) return res.status(400).json({ erro: "Tipo inválido." });
  if (!req.file.originalname.toLowerCase().endsWith(".zip")) {
    return res.status(400).json({ erro: "O arquivo precisa ser um .zip." });
  }

  const id = nanoid(8).toLowerCase();
  const baseDir = path.join(DATA_DIR, tipo === "static" ? "sites" : "apis", id);

  try {
    extractZipSafe(req.file.buffer, baseDir);
    flattenSingleRoot(baseDir);
  } catch (err) {
    fs.rmSync(baseDir, { recursive: true, force: true });
    return res.status(400).json({ erro: err.message });
  }

  registry.put(id, {
    type: tipo,
    name: (nome || id).slice(0, 60),
    createdAt: Date.now(),
    status: tipo === "static" ? "online" : "instalando",
  });

  if (tipo === "static") {
    if (!fs.existsSync(path.join(baseDir, "index.html"))) {
      registry.put(id, { warning: "Nenhum index.html encontrado na raiz do zip." });
    }
    return res.status(201).json({ id, tipo, url: `/site/${id}/` });
  }

  // tipo === "api": deploy é assíncrono (instala deps e sobe o processo)
  res.status(202).json({ id, tipo, url: `/api/${id}/`, status: "instalando" });
  runner.deployApi(id, baseDir).catch((err) => {
    registry.put(id, { status: "erro", error: err.message });
  });
});

// ---------- Servir sites estáticos ----------
app.use("/site/:id", (req, res, next) => {
  const record = registry.get(req.params.id);
  if (!record || record.type !== "static") return res.status(404).send("Site não encontrado.");
  express.static(path.join(DATA_DIR, "sites", req.params.id))(req, res, next);
});
app.get("/site/:id/*", (req, res) => {
  const record = registry.get(req.params.id);
  if (!record || record.type !== "static") return res.status(404).send("Site não encontrado.");
  const indexPath = path.join(DATA_DIR, "sites", req.params.id, "index.html");
  if (fs.existsSync(indexPath)) res.sendFile(indexPath);
  else res.status(404).send("index.html não encontrado nesse deploy.");
});

// ---------- Proxy para as APIs hospedadas ----------
app.use("/api/:id", (req, res, next) => {
  const { id } = req.params;
  const record = registry.get(id);
  if (!record || record.type !== "api") return res.status(404).json({ erro: "API não encontrada." });
  if (record.status !== "online") {
    return res.status(503).json({ erro: `API indisponível (status: ${record.status}).` });
  }
  const port = runner.getPort(id);
  if (!port) return res.status(503).json({ erro: "API ainda não está pronta." });

  runner.touch(id);
  createProxyMiddleware({
    target: `http://127.0.0.1:${port}`,
    changeOrigin: true,
    pathRewrite: { [`^/api/${id}`]: "" },
  })(req, res, next);
});

app.listen(PORT, () => {
  console.log(`hospeda-real rodando na porta ${PORT}`);
});
